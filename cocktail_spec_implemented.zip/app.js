
const all=[...(window.vol1||[]),...(window.vol2||[]),...(window.vol3||[]),...(window.vol4||[]),...(window.vol5||[]),...(window.vol6||[]),...(window.vol7||[]),...(window.vol8||[])];

let selected=[],pool=[],index=0,correct=0,answered=[];

function home(){
document.getElementById("app").innerHTML=`
<h1>Cocktail Study</h1>
${[1,2,3,4,5,6,7,8].map(v=>`<label><input type="checkbox" class="vol" value="${v}" checked>Vol${v}</label><br>`).join("")}
<button onclick="start()">順番学習</button>`;
}

function start(){
selected=[...document.querySelectorAll(".vol:checked")].map(x=>Number(x.value));
pool=all.filter(x=>selected.includes(Number(x.vol)));
index=0;
correct=0;
answered=[];
if(pool.length===0){alert("Volを選択してください");return;}
show();
}

function normalize(s){
return s.toLowerCase()
.replace(/cc/g,"")
.replace(/[、,\s　]/g,"");
}

function show(){
const q=pool[index];
document.getElementById("app").innerHTML=`
<button onclick="home()">ホーム</button>
<button onclick="back()">戻る</button>
<div>${index+1}/${pool.length}</div>
<h2>問題</h2>
<h1>${q.name}</h1>
<input id="answer" placeholder="レシピを入力">
<button onclick="judge()">解答する</button>`;
}

function judge(){
if(answered[index]) return;

const q=pool[index];
const user=normalize(document.getElementById("answer").value);

const tokens=q.recipe.split("、").map(x=>normalize(x));
const ok=tokens.every(t=>user.includes(t));

answered[index]=true;
if(ok) correct++;

document.getElementById("app").innerHTML+=`
<hr>
<h2>${ok?"○ 正解":"× 不正解"}</h2>
<p>正解: ${q.recipe}</p>
<p>グラス: ${q.glass}</p>
<p>付属: ${q.garnish||"なし"}</p>
<p>${q.history||""}</p>
<button onclick="next()">次の問題</button>`;
}

function next(){
index++;
if(index>=pool.length){
document.getElementById("app").innerHTML=`
<h1>採点結果</h1>
<p>${pool.length}問中 ${correct}問正解</p>
<p>正答率 ${Math.round(correct/pool.length*100)}%</p>
<button onclick="home()">ホーム</button>`;
return;
}
show();
}

function back(){
if(index===0){alert("1問目の問題です");return;}
index--;
show();
}

window.onload=home;
